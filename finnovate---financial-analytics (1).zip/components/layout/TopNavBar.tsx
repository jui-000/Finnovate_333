
import React, { useContext } from 'react';
import { Page } from '../../types';
import { NAV_ITEMS, InsightsIcon, SunIcon, MoonIcon, UserCircleIcon } from '../../constants';
import { ThemeContext } from '../../App';

interface TopNavBarProps {
  currentPage: Page;
  setCurrentPage: (page: Page) => void;
}

const TopNavBar: React.FC<TopNavBarProps> = ({ currentPage, setCurrentPage }) => {
  const themeContext = useContext(ThemeContext);

  return (
    <header className="bg-white dark:bg-secondary-900 shadow-md sticky top-0 z-40">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo and App Name */}
          <div className="flex items-center space-x-3">
            <div className="text-primary-600 dark:text-primary-400">
              <InsightsIcon />
            </div>
            <span className="text-xl font-bold text-primary-600 dark:text-primary-400">Finnovate</span>
          </div>

          {/* Navigation Links */}
          <nav className="hidden md:flex items-center space-x-2">
            {NAV_ITEMS.map((item) => (
              <button
                key={item.page}
                onClick={() => setCurrentPage(item.page)}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200 ${
                  currentPage === item.page
                    ? 'bg-primary-600 text-white'
                    : 'text-secondary-600 dark:text-secondary-300 hover:bg-secondary-100 dark:hover:bg-secondary-800'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* Right-side Icons */}
          <div className="flex items-center space-x-4">
            <button
              onClick={themeContext?.toggleTheme}
              className="p-2 rounded-full text-secondary-600 dark:text-secondary-300 hover:bg-secondary-100 dark:hover:bg-secondary-800 focus:outline-none"
              aria-label="Toggle theme"
            >
              {themeContext?.theme === 'light' ? <MoonIcon /> : <SunIcon />}
            </button>
            <button
              onClick={() => setCurrentPage(Page.SignIn)}
              className="p-2 rounded-full text-secondary-600 dark:text-secondary-300 hover:bg-secondary-100 dark:hover:bg-secondary-800 focus:outline-none"
              aria-label="User profile"
            >
                <UserCircleIcon />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default TopNavBar;