import React from 'react';
import { Page } from '../../types';
import DashboardPage from '../../pages/DashboardPage';
import PredictionPage from '../../pages/PredictionPage';
import InsightsPage from '../../pages/InsightsPage';
import TopNavBar from './TopNavBar';

interface MainLayoutProps {
  currentPage: Page;
  setCurrentPage: (page: Page) => void;
}

const MainLayout: React.FC<MainLayoutProps> = ({ currentPage, setCurrentPage }) => {
  const renderPage = () => {
    switch (currentPage) {
      case Page.Dashboard:
        return <DashboardPage />;
      case Page.Prediction:
        return <PredictionPage />;
      case Page.Insights:
        return <InsightsPage />;
      default:
        return <DashboardPage />;
    }
  };

  return (
    <div className="flex flex-col h-screen bg-secondary-100 dark:bg-secondary-950">
      <TopNavBar currentPage={currentPage} setCurrentPage={setCurrentPage} />
      <main className="flex-1 overflow-x-hidden overflow-y-auto bg-secondary-100 dark:bg-secondary-950 p-4 md:p-8">
        {renderPage()}
      </main>
    </div>
  );
};

export default MainLayout;