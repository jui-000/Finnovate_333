import React from 'react';

interface KpiCardProps {
  title: string;
  value: string | number;
  change?: string;
  changeType?: 'increase' | 'decrease';
  icon: React.ReactNode;
}

const KpiCard: React.FC<KpiCardProps> = ({ title, value, change, changeType, icon }) => {
  const changeColor = changeType === 'increase' ? 'text-green-500' : 'text-red-500';
  const changeArrow = changeType === 'increase' ? '↑' : '↓';

  return (
    <div className="bg-white dark:bg-secondary-900 p-5 rounded-xl shadow-md flex flex-col justify-between h-full">
      <div className="flex justify-between items-start">
        <span className="text-sm font-medium text-secondary-500 dark:text-secondary-400">{title}</span>
        <div className="text-secondary-500 dark:text-secondary-400">
            {icon}
        </div>
      </div>
      <div>
        <p className="text-3xl font-bold text-secondary-900 dark:text-secondary-100 mt-2">{value}</p>
        {change && (
          <p className={`text-sm mt-1 flex items-center ${changeColor}`}>
            <span>{changeArrow}</span>
            <span className="ml-1">{change}</span>
          </p>
        )}
      </div>
    </div>
  );
};

export default KpiCard;