
import React from 'react';

interface TableProps {
  headers: string[];
  data: { [key: string]: string | number }[];
}

const Table: React.FC<TableProps> = ({ headers, data }) => {
    if (!data || data.length === 0) {
        return <p className="text-center text-secondary-500 dark:text-secondary-400 mt-4">No data to display.</p>
    }

  return (
    <div className="overflow-x-auto bg-white dark:bg-secondary-900 rounded-lg shadow mt-4">
      <table className="min-w-full divide-y divide-secondary-200 dark:divide-secondary-700">
        <thead className="bg-secondary-50 dark:bg-secondary-800">
          <tr>
            {headers.map((header) => (
              <th
                key={header}
                scope="col"
                className="px-6 py-3 text-left text-xs font-medium text-secondary-500 dark:text-secondary-300 uppercase tracking-wider"
              >
                {header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="bg-white dark:bg-secondary-900 divide-y divide-secondary-200 dark:divide-secondary-700">
          {data.map((row, rowIndex) => (
            <tr key={rowIndex} className="hover:bg-secondary-50 dark:hover:bg-secondary-800">
              {headers.map((header) => (
                <td key={`${header}-${rowIndex}`} className="px-6 py-4 whitespace-nowrap text-sm text-secondary-700 dark:text-secondary-300">
                  {row[header]}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Table;
