
import React from 'react';

interface CardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  description?: string;
}

const Card: React.FC<CardProps> = ({ title, value, icon, description }) => {
  return (
    <div className="bg-white dark:bg-secondary-900 p-6 rounded-xl shadow-md flex items-center space-x-4">
      <div className="flex-shrink-0">
        <div className="p-3 bg-primary-100 dark:bg-primary-900/50 rounded-full text-primary-600 dark:text-primary-300">
          {icon}
        </div>
      </div>
      <div>
        <p className="text-sm text-secondary-500 dark:text-secondary-400">{title}</p>
        <p className="text-2xl font-bold text-secondary-900 dark:text-secondary-100">{value}</p>
        {description && <p className="text-xs text-secondary-400">{description}</p>}
      </div>
    </div>
  );
};

export default Card;
