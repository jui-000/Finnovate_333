import React, { useContext } from 'react';
import { ThemeContext } from '../../App';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const data = [
  { name: 'Jan', Revenue: 680, Expenses: 500 },
  { name: 'Feb', Revenue: 720, Expenses: 520 },
  { name: 'Mar', Revenue: 750, Expenses: 510 },
  { name: 'Apr', Revenue: 780, Expenses: 530 },
  { name: 'May', Revenue: 810, Expenses: 540 },
  { name: 'Jun', Revenue: 840, Expenses: 550 },
];

const RevenueTrendChart: React.FC = () => {
    const themeContext = useContext(ThemeContext);
    const isDarkMode = themeContext?.theme === 'dark';

    return (
        <div className="w-full h-80 bg-white dark:bg-secondary-900 p-4 rounded-xl shadow-md">
            <h3 className="font-bold text-lg mb-4 text-secondary-800 dark:text-secondary-200">Revenue & Expenses Trend (in ₹100k)</h3>
            <ResponsiveContainer>
                <LineChart
                    data={data}
                    margin={{
                        top: 5,
                        right: 30,
                        left: 0,
                        bottom: 5,
                    }}
                >
                    <CartesianGrid strokeDasharray="3 3" stroke={isDarkMode ? '#334155' : '#e2e8f0'} />
                    <XAxis dataKey="name" stroke={isDarkMode ? '#94a3b8' : '#64748b'} fontSize={12} />
                    <YAxis stroke={isDarkMode ? '#94a3b8' : '#64748b'} fontSize={12} />
                    <Tooltip
                        contentStyle={{
                            backgroundColor: isDarkMode ? '#1e293b' : '#ffffff',
                            borderColor: isDarkMode ? '#334155' : '#e2e8f0',
                        }}
                    />
                    <Legend />
                    <Line type="monotone" dataKey="Revenue" stroke="#3b82f6" strokeWidth={2} activeDot={{ r: 8 }} />
                    <Line type="monotone" dataKey="Expenses" stroke="#94a3b8" strokeWidth={2} />
                </LineChart>
            </ResponsiveContainer>
        </div>
    );
};

export default RevenueTrendChart;
