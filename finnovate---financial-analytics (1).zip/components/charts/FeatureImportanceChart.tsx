import React, { useContext } from 'react';
import { ThemeContext } from '../../App';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface FeatureImportanceChartProps {
    data: { name: string; importance: number }[];
}

const FeatureImportanceChart: React.FC<FeatureImportanceChartProps> = ({ data }) => {
    const themeContext = useContext(ThemeContext);
    const isDarkMode = themeContext?.theme === 'dark';

    return (
        <div className="w-full h-96 bg-white dark:bg-secondary-900 p-4 rounded-xl shadow-md">
            <h3 className="font-bold text-lg mb-4">Top 5 Factors Influencing Churn</h3>
            <ResponsiveContainer>
                <BarChart data={data} layout="vertical" margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke={isDarkMode ? '#334155' : '#e2e8f0'} />
                    <XAxis type="number" stroke={isDarkMode ? '#94a3b8' : '#64748b'} />
                    <YAxis dataKey="name" type="category" width={100} stroke={isDarkMode ? '#94a3b8' : '#64748b'} />
                    <Tooltip
                        contentStyle={{
                            backgroundColor: isDarkMode ? '#1e293b' : '#ffffff',
                            borderColor: isDarkMode ? '#334155' : '#e2e8f0',
                        }}
                    />
                    <Legend />
                    <Bar dataKey="importance" fill="#3b82f6" />
                </BarChart>
            </ResponsiveContainer>
        </div>
    );
};

export default FeatureImportanceChart;