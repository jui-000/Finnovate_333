import React, { useContext } from 'react';
import { ThemeContext } from '../../App';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const data = [
  { name: 'Q3 \'23', 'Churn Rate': 9.8 },
  { name: 'Q4 \'23', 'Churn Rate': 10.1 },
  { name: 'Q1 \'24', 'Churn Rate': 10.2 },
  { name: 'Q2 \'24', 'Churn Rate': 12.5 },
];

const ChurnTrendChart: React.FC = () => {
    const themeContext = useContext(ThemeContext);
    const isDarkMode = themeContext?.theme === 'dark';

    return (
        <div className="w-full h-80 bg-white dark:bg-secondary-900 p-4 rounded-xl shadow-md">
            <h3 className="font-bold text-lg mb-4 text-secondary-800 dark:text-secondary-200">Churn Rate Trend</h3>
            <ResponsiveContainer>
                <LineChart
                    data={data}
                    margin={{
                        top: 5,
                        right: 30,
                        left: -10,
                        bottom: 5,
                    }}
                >
                    <CartesianGrid strokeDasharray="3 3" stroke={isDarkMode ? '#334155' : '#e2e8f0'} horizontal={true} vertical={false}/>
                    <XAxis dataKey="name" stroke={isDarkMode ? '#94a3b8' : '#64748b'} fontSize={12} />
                    <YAxis stroke={isDarkMode ? '#94a3b8' : '#64748b'} fontSize={12} />
                    <Tooltip
                        contentStyle={{
                            backgroundColor: isDarkMode ? '#1e293b' : '#ffffff',
                            borderColor: isDarkMode ? '#334155' : '#e2e8f0',
                        }}
                    />
                    <Line type="monotone" dataKey="Churn Rate" stroke="#ef4444" strokeWidth={3} dot={{ r: 5 }} activeDot={{ r: 8 }} />
                </LineChart>
            </ResponsiveContainer>
        </div>
    );
};

export default ChurnTrendChart;
