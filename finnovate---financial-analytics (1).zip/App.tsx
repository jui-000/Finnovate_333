
import React, { useState, useEffect, createContext, useCallback } from 'react';
import { Page, Theme } from './types';
import HomePage from './pages/HomePage';
import MainLayout from './components/layout/MainLayout';
import SignInPage from './pages/SignInPage';
import SignUpPage from './pages/SignUpPage';

interface ThemeContextType {
  theme: Theme;
  toggleTheme: () => void;
}

export const ThemeContext = createContext<ThemeContextType | null>(null);

const App: React.FC = () => {
  const [theme, setTheme] = useState<Theme>('light');
  const [currentPage, setCurrentPage] = useState<Page>(Page.Home);

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme') as Theme | null;
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    if (savedTheme) {
      setTheme(savedTheme);
    } else if (prefersDark) {
      setTheme('dark');
    }
  }, []);

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prevTheme => (prevTheme === 'light' ? 'dark' : 'light'));
  };

  const navigateToDashboard = useCallback(() => {
    setCurrentPage(Page.Dashboard);
  }, []);

  const navigateToSignIn = useCallback(() => {
    setCurrentPage(Page.SignIn);
  }, []);
  
  const navigateToSignUp = useCallback(() => {
    setCurrentPage(Page.SignUp);
  }, []);

  const renderContent = () => {
    switch (currentPage) {
      case Page.Home:
        return <HomePage onGoToDashboard={navigateToDashboard} />;
      case Page.SignIn:
        return <SignInPage onSignInSuccess={navigateToDashboard} onNavigateToSignUp={navigateToSignUp} />;
      case Page.SignUp:
        return <SignUpPage onSignUpSuccess={navigateToSignIn} onNavigateToSignIn={navigateToSignIn} />;
      default:
        return <MainLayout currentPage={currentPage} setCurrentPage={setCurrentPage} />;
    }
  };

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      <div className="min-h-screen text-secondary-800 dark:text-secondary-200">
        {renderContent()}
      </div>
    </ThemeContext.Provider>
  );
};

export default App;