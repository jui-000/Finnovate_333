import React, { useState } from 'react';
import Button from '../components/ui/Button';
import { generateBusinessInsights } from '../services/geminiService';
import LoadingSpinner from '../components/ui/LoadingSpinner';

const SimpleMarkdown: React.FC<{ text: string }> = ({ text }) => {
    const formattedText = text
        .replace(/^### (.*$)/gim, '<h3 class="text-xl font-bold mt-4 mb-2">$1</h3>')
        .replace(/^## (.*$)/gim, '<h2 class="text-2xl font-bold mt-6 mb-3">$1</h2>')
        .replace(/^# (.*$)/gim, '<h1 class="text-3xl font-bold mt-8 mb-4">$1</h1>')
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.*?)\*/g, '<em>$1</em>')
        .replace(/^- (.*$)/gim, '<li class="ml-4 mb-1">$1</li>')
        .replace(/(\n<li>)/g, '<ul>$1')
        .replace(/(<\/li>\n)(?!<li>)/g, '$1</ul>');

    return <div className="prose dark:prose-invert max-w-none" dangerouslySetInnerHTML={{ __html: formattedText }} />;
}

const InsightsPage: React.FC = () => {
    const [summary, setSummary] = useState("Our customer base consists of 7043 users. The churn rate is 26.5%. Most churned users are on month-to-month contracts, have fiber optic internet, and use electronic checks for payment. High monthly charges and low tenure are also common factors among churned customers.");
    const [insights, setInsights] = useState<string>('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleGenerate = async () => {
        if (!summary.trim()) {
            setError("Please provide a summary of your customer data.");
            return;
        }
        setIsLoading(true);
        setError(null);
        setInsights('');

        try {
            const result = await generateBusinessInsights(summary);
            setInsights(result);
        } catch (err) {
            setError("An error occurred while generating insights. Please try again.");
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="space-y-8">
             <h1 className="text-3xl font-bold text-secondary-900 dark:text-secondary-100">Forecasting & Insights</h1>
            <div className="bg-white dark:bg-secondary-900 p-6 rounded-xl shadow-md">
                <h2 className="text-2xl font-bold mb-4">Generate Business Strategy Insights</h2>
                <p className="mb-4 text-secondary-600 dark:text-secondary-400">
                    Provide a summary of your customer churn data below. Our AI-powered analyst will generate actionable strategies to help you improve retention and profitability.
                </p>
                <textarea
                    value={summary}
                    onChange={(e) => setSummary(e.target.value)}
                    rows={6}
                    className="w-full p-3 bg-secondary-50 dark:bg-secondary-800 border border-secondary-300 dark:border-secondary-700 rounded-md focus:ring-2 focus:ring-primary-500 focus:outline-none"
                    placeholder="e.g., High churn rate (35%) among new customers on our basic plan..."
                />
                 {error && <p className="text-red-500 mt-2">{error}</p>}
                <Button onClick={handleGenerate} isLoading={isLoading} className="mt-4">
                    Generate Insights
                </Button>
            </div>

            {isLoading && <LoadingSpinner />}

            {insights && (
                <div className="bg-white dark:bg-secondary-900 p-6 rounded-xl shadow-md animate-fade-in">
                    <h3 className="text-2xl font-bold mb-4">AI-Generated Insights</h3>
                    <div className="text-secondary-700 dark:text-secondary-300 space-y-4">
                        <SimpleMarkdown text={insights} />
                    </div>
                </div>
            )}
        </div>
    );
};

export default InsightsPage;