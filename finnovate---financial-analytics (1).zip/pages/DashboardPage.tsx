import React from 'react';
import KpiCard from '../components/ui/KpiCard';
import RevenueTrendChart from '../components/charts/RevenueTrendChart';
import { DollarIcon, TrendUpIcon, CostIcon, HeartIcon, CheckmarkCircleIcon } from '../constants';

const DashboardPage: React.FC = () => {
  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold text-secondary-900 dark:text-secondary-100">Financial Dashboard</h1>
      
      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <KpiCard 
          title="Total Revenue" 
          value="₹8.20M" 
          change="7.9% vs last quarter" 
          changeType="increase" 
          icon={<DollarIcon className="w-6 h-6" />}
        />
        <KpiCard 
          title="Profit Margin" 
          value="18.4%" 
          change="26.0% vs last quarter" 
          changeType="increase" 
          icon={<TrendUpIcon className="w-6 h-6" />}
        />
        <KpiCard 
          title="Customer Acquisition Cost" 
          value="₹450" 
          change="-5.2% vs last quarter" 
          changeType="decrease" 
          icon={<CostIcon className="w-6 h-6" />}
        />
        <KpiCard 
          title="Customer Lifetime Value" 
          value="₹4800" 
          change="+8.1% vs last quarter" 
          changeType="increase" 
          icon={<HeartIcon className="w-6 h-6" />}
        />
      </div>

      {/* Charts and Summaries */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
            <RevenueTrendChart />
        </div>
        <div className="bg-white dark:bg-secondary-900 p-5 rounded-xl shadow-md flex flex-col justify-center text-center">
            <h3 className="font-bold text-lg mb-4 text-secondary-800 dark:text-secondary-200">Quarterly Summary</h3>
            <div className="flex-grow flex flex-col items-center justify-center">
                <CheckmarkCircleIcon className="w-24 h-24 text-green-500" />
                <p className="mt-4 text-sm text-secondary-600 dark:text-secondary-300">
                    A strong quarter with revenue growth of <strong className="text-green-500">7.9%</strong> and a significant improvement in profit margins.
                </p>
                <p className="mt-2 text-xs text-secondary-400">Operating expenses are stable.</p>
            </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;