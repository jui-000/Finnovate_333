import React, { useState } from 'react';
import Button from '../components/ui/Button';
import { PREDICTION_FORM_OPTIONS, UserLeaveIcon, ArrowCircleRightIcon, UsersIcon, DollarIcon } from '../constants';
import FeatureImportanceChart from '../components/charts/FeatureImportanceChart';
import LoadingSpinner from '../components/ui/LoadingSpinner';
import KpiCard from '../components/ui/KpiCard';
import ChurnTrendChart from '../components/charts/ChurnTrendChart';
import { CustomerData } from '../types';
import ChurnPieChart from '../components/charts/ChurnPieChart';
import Table from '../components/ui/Table';

type PredictionResult = {
  result: 'Churn' | 'No Churn';
  probability: number;
  riskLevel: 'Low' | 'Medium' | 'High';
  recommendations: string[];
};

type AnalysisKPIs = {
    totalCustomers: number;
    churnPercentage: string;
    avgMonthlyCharges: string;
    churnPieData: { name: string; value: number }[];
};

// Mock Feature Importance Data
const featureImportanceData = [
  { name: 'Contract', importance: 0.45 },
  { name: 'Tenure', importance: 0.25 },
  { name: 'MonthlyCharges', importance: 0.15 },
  { name: 'InternetService', importance: 0.1 },
  { name: 'PaymentMethod', importance: 0.05 },
];

const PredictionPage: React.FC = () => {
  const [formData, setFormData] = useState({
    gender: 'Male', SeniorCitizen: 0, Partner: 'Yes', Dependents: 'No',
    tenure: 12, PhoneService: 'Yes', MultipleLines: 'No', InternetService: 'DSL',
    OnlineSecurity: 'No', OnlineBackup: 'Yes', DeviceProtection: 'No',
    TechSupport: 'No', StreamingTV: 'No', StreamingMovies: 'No',
    Contract: 'Month-to-month', PaperlessBilling: 'Yes', PaymentMethod: 'Electronic check',
    MonthlyCharges: 29.85, TotalCharges: 29.85,
  });
  const [isLoading, setIsLoading] = useState(false);
  const [prediction, setPrediction] = useState<PredictionResult | null>(null);

  const [customerData, setCustomerData] = useState<CustomerData[]>([]);
  const [analysisKpis, setAnalysisKpis] = useState<AnalysisKPIs | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [fileName, setFileName] = useState('');

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    setIsAnalyzing(true);
    setAnalysisKpis(null);

    const reader = new FileReader();
    reader.onload = (event) => {
        const text = event.target?.result as string;
        const rows = text.split('\n').filter(row => row.trim() !== '');
        const header = rows[0].split(',').map(h => h.trim());
        const data: CustomerData[] = [];

        const numericFields = ['tenure', 'MonthlyCharges', 'TotalCharges', 'SeniorCitizen'];

        for (let i = 1; i < rows.length; i++) {
            const values = rows[i].split(',').map(v => v.trim());
            const rowData = header.reduce((obj, key, index) => {
                const value = values[index];
                if (numericFields.includes(key)) {
                    const numValue = parseFloat(value);
                    obj[key] = isNaN(numValue) ? 0 : numValue;
                } else {
                    obj[key] = value;
                }
                return obj;
            }, {} as any);
            data.push(rowData);
        }
        setCustomerData(data);
        analyzeData(data);
    };
    reader.readAsText(file);
  };

  const analyzeData = (data: CustomerData[]) => {
    if (data.length === 0) {
        setIsAnalyzing(false);
        return;
    }
    
    const totalCustomers = data.length;
    const churnedCustomers = data.filter(c => c.Churn === 'Yes').length;
    const churnPercentage = totalCustomers > 0 ? ((churnedCustomers / totalCustomers) * 100).toFixed(1) + '%' : '0%';
    const totalMonthlyCharges = data.reduce((sum, c) => sum + (c.MonthlyCharges || 0), 0);
    const avgMonthlyCharges = totalCustomers > 0 ? `₹${(totalMonthlyCharges / totalCustomers).toFixed(2)}` : '₹0.00';

    setAnalysisKpis({
        totalCustomers,
        churnPercentage,
        avgMonthlyCharges,
        churnPieData: [
            { name: 'Active', value: totalCustomers - churnedCustomers },
            { name: 'Churned', value: churnedCustomers },
        ],
    });
    setIsAnalyzing(false);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: (e.target.type === 'number' && value !== '') ? parseFloat(value) : value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setPrediction(null);
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const churnProbability = Math.random();
    const result: PredictionResult = {
        result: churnProbability > 0.4 ? 'Churn' : 'No Churn',
        probability: parseFloat((churnProbability * 100).toFixed(2)),
        riskLevel: churnProbability > 0.7 ? 'High' : churnProbability > 0.4 ? 'Medium' : 'Low',
        recommendations: churnProbability > 0.4
            ? ["Offer loyalty discounts to reduce churn risk.", "Proactively reach out with a customer satisfaction survey.", "Highlight benefits of annual contracts."]
            : ["Encourage exploring new services.", "Send a thank-you note for their loyalty."]
    };
    setPrediction(result);
    setIsLoading(false);
  };

  const renderInputField = (key: string, label: string) => (
    <div key={key}>
        <label htmlFor={key} className="block text-sm font-medium text-secondary-700 dark:text-secondary-300">{label}</label>
        <input type="number" id={key} name={key} value={formData[key as keyof typeof formData] as number} onChange={handleChange}
            className="mt-1 block w-full px-3 py-2 bg-white dark:bg-secondary-800 border border-secondary-300 dark:border-secondary-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm" />
    </div>
  );

  const renderSelectField = (key: string, label: string, options: (string|number)[]) => (
    <div key={key}>
        <label htmlFor={key} className="block text-sm font-medium text-secondary-700 dark:text-secondary-300">{label}</label>
        <select id={key} name={key} value={formData[key as keyof typeof formData]} onChange={handleChange}
            className="mt-1 block w-full px-3 py-2 bg-white dark:bg-secondary-800 border border-secondary-300 dark:border-secondary-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm">
            {options.map(option => <option key={option} value={option}>{option === 0 ? 'No' : option === 1 ? 'Yes' : option}</option>)}
        </select>
    </div>
  );

  return (
    <div className="space-y-8">
        <section>
            <h1 className="text-3xl font-bold text-secondary-900 dark:text-secondary-100 mb-6">Customer Churn Analysis</h1>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="md:col-span-1 grid grid-cols-1 gap-6">
                    <KpiCard title="Quarterly Churn Rate" value="12.5%" change="21.4% vs last quarter" changeType="decrease" icon={<UserLeaveIcon className="w-6 h-6"/>} />
                    <KpiCard title="High-Risk Customers" value="3" icon={<ArrowCircleRightIcon className="w-6 h-6"/>} />
                </div>
                <div className="md:col-span-2">
                    <ChurnTrendChart />
                </div>
            </div>
        </section>

        <hr className="border-secondary-200 dark:border-secondary-800" />

        <section>
            <h2 className="text-2xl font-bold mb-6 text-secondary-900 dark:text-secondary-100">Analyze Your Customer Data</h2>
            <div className="bg-white dark:bg-secondary-900 p-6 rounded-xl shadow-md">
                <label htmlFor="file-upload" className="cursor-pointer inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700">
                    Upload CSV
                </label>
                <input id="file-upload" name="file-upload" type="file" className="sr-only" accept=".csv" onChange={handleFileChange} />
                {fileName && <span className="ml-4 text-sm text-secondary-600 dark:text-secondary-400">{fileName}</span>}
            </div>
            {isAnalyzing && <LoadingSpinner />}
            {analysisKpis && customerData.length > 0 && (
                <div className="mt-6 space-y-6 animate-fade-in">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <KpiCard title="Total Customers" value={analysisKpis.totalCustomers} icon={<UsersIcon className="w-6 h-6" />} />
                        <KpiCard title="Churn Percentage" value={analysisKpis.churnPercentage} icon={<UserLeaveIcon className="w-6 h-6" />} />
                        <KpiCard title="Avg. Monthly Charges" value={analysisKpis.avgMonthlyCharges} icon={<DollarIcon className="w-6 h-6" />} />
                    </div>
                    <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
                        <div className="lg:col-span-2">
                            <ChurnPieChart data={analysisKpis.churnPieData} />
                        </div>
                        <div className="lg:col-span-3">
                             <Table headers={Object.keys(customerData[0])} data={customerData.slice(0, 10)} />
                             {customerData.length > 10 && <p className="text-xs text-center mt-2 text-secondary-500">Showing first 10 of {customerData.length} rows.</p>}
                        </div>
                    </div>
                </div>
            )}
        </section>

        <hr className="border-secondary-200 dark:border-secondary-800" />
        
        <section className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-white dark:bg-secondary-900 p-6 rounded-xl shadow-md">
                <h2 className="text-2xl font-bold mb-6">Predict Churn for a Customer</h2>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {renderSelectField('gender', 'Gender', PREDICTION_FORM_OPTIONS.gender)}
                        {renderSelectField('SeniorCitizen', 'Senior Citizen', PREDICTION_FORM_OPTIONS.SeniorCitizen)}
                        {renderSelectField('Partner', 'Partner', PREDICTION_FORM_OPTIONS.Partner)}
                        {renderSelectField('Dependents', 'Dependents', PREDICTION_FORM_OPTIONS.Dependents)}
                        {renderInputField('tenure', 'Tenure (months)')}
                        {renderSelectField('PhoneService', 'Phone Service', PREDICTION_FORM_OPTIONS.PhoneService)}
                        {renderSelectField('MultipleLines', 'Multiple Lines', PREDICTION_FORM_OPTIONS.MultipleLines)}
                        {renderSelectField('InternetService', 'Internet Service', PREDICTION_FORM_OPTIONS.InternetService)}
                        {renderSelectField('Contract', 'Contract', PREDICTION_FORM_OPTIONS.Contract)}
                        {renderSelectField('PaymentMethod', 'Payment Method', PREDICTION_FORM_OPTIONS.PaymentMethod)}
                        {renderInputField('MonthlyCharges', 'Monthly Charges')}
                        {renderInputField('TotalCharges', 'Total Charges')}
                    </div>
                    <Button type="submit" isLoading={isLoading} className="w-full">
                        Predict Churn
                    </Button>
                </form>
            </div>

            <div className="space-y-8">
                {isLoading && <LoadingSpinner />}
                {prediction && (
                    <div className="bg-white dark:bg-secondary-900 p-6 rounded-xl shadow-md animate-fade-in">
                        <h3 className="text-2xl font-bold mb-4">Prediction Result</h3>
                        <div className="space-y-3">
                            <p className="text-lg">Result: <span className={`font-bold ${prediction.result === 'Churn' ? 'text-red-500' : 'text-green-500'}`}>{prediction.result}</span></p>
                            <p className="text-lg">Probability: <span className="font-bold">{prediction.probability}%</span></p>
                            <p className="text-lg">Risk Level: <span className="font-bold">{prediction.riskLevel}</span></p>
                        </div>
                        <div className="mt-6">
                            <h4 className="font-bold text-lg mb-2">Personalized Recommendations:</h4>
                            <ul className="list-disc list-inside space-y-1 text-secondary-600 dark:text-secondary-300">
                                {prediction.recommendations.map((rec, i) => <li key={i}>{rec}</li>)}
                            </ul>
                        </div>
                    </div>
                )}
                <FeatureImportanceChart data={featureImportanceData} />
            </div>
        </section>
    </div>
  );
};

export default PredictionPage;