
import React, { useState } from 'react';
import { InsightsIcon } from '../constants';
import Button from '../components/ui/Button';

interface SignUpPageProps {
  onSignUpSuccess: () => void;
  onNavigateToSignIn: () => void;
}

const SignUpPage: React.FC<SignUpPageProps> = ({ onSignUpSuccess, onNavigateToSignIn }) => {
  const [isLoading, setIsLoading] = useState(false);
  
  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    setIsLoading(false);
    onSignUpSuccess();
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-secondary-100 dark:bg-secondary-950 px-4 py-12">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center">
          <div className="inline-block text-primary-600 dark:text-primary-400">
            <InsightsIcon />
          </div>
          <h2 className="mt-6 text-3xl font-bold tracking-tight text-secondary-900 dark:text-white">
            Create your Finnovate account
          </h2>
          <p className="mt-2 text-sm text-secondary-600 dark:text-secondary-400">
            Start making data-driven decisions today.
          </p>
        </div>
        
        <div className="bg-white dark:bg-secondary-900 shadow-xl rounded-2xl p-8 space-y-6">
          <form className="space-y-4" onSubmit={handleSignUp}>
            <div>
              <label htmlFor="fullName" className="block text-sm font-medium text-secondary-700 dark:text-secondary-300">
                Full Name
              </label>
              <div className="mt-1">
                <input id="fullName" name="fullName" type="text" required
                  className="block w-full px-3 py-2 bg-white dark:bg-secondary-800 border border-secondary-300 dark:border-secondary-600 rounded-md shadow-sm placeholder-secondary-400 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                />
              </div>
            </div>

            <div>
              <label htmlFor="companyName" className="block text-sm font-medium text-secondary-700 dark:text-secondary-300">
                Company Name
              </label>
              <div className="mt-1">
                <input id="companyName" name="companyName" type="text" required
                  className="block w-full px-3 py-2 bg-white dark:bg-secondary-800 border border-secondary-300 dark:border-secondary-600 rounded-md shadow-sm placeholder-secondary-400 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                />
              </div>
            </div>

            <div>
              <label htmlFor="email" className="block text-sm font-medium text-secondary-700 dark:text-secondary-300">
                Email address
              </label>
              <div className="mt-1">
                <input id="email" name="email" type="email" autoComplete="email" required
                  className="block w-full px-3 py-2 bg-white dark:bg-secondary-800 border border-secondary-300 dark:border-secondary-600 rounded-md shadow-sm placeholder-secondary-400 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                />
              </div>
            </div>

            <div>
              <label htmlFor="password"className="block text-sm font-medium text-secondary-700 dark:text-secondary-300">
                Password
              </label>
              <div className="mt-1">
                <input id="password" name="password" type="password" autoComplete="new-password" required
                  className="block w-full px-3 py-2 bg-white dark:bg-secondary-800 border border-secondary-300 dark:border-secondary-600 rounded-md shadow-sm placeholder-secondary-400 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                />
              </div>
            </div>
            
            <Button type="submit" className="w-full" isLoading={isLoading}>
              Create Account
            </Button>
          </form>
        </div>

        <p className="text-center text-sm text-secondary-600 dark:text-secondary-400">
          Already have an account?{' '}
          <button onClick={onNavigateToSignIn} className="font-medium text-primary-600 hover:text-primary-500 focus:outline-none">
            Sign in
          </button>
        </p>
      </div>
    </div>
  );
};

export default SignUpPage;
