
import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("API_KEY is not set. Gemini API calls will fail.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

export const generateBusinessInsights = async (dataSummary: string): Promise<string> => {
  if (!API_KEY) {
    return Promise.resolve("Error: API_KEY for Gemini is not configured. Please set the API_KEY environment variable.");
  }
  
  try {
    const prompt = `
      You are Finnovate, an expert financial and business strategy analyst. 
      Your goal is to provide actionable insights to help businesses grow and improve profitability by reducing customer churn.

      Based on the following customer data summary, provide clear, concise, and actionable business strategy tips.
      Structure your response in Markdown format. Use headings, bold text, and bullet points to make it easy to read.

      Customer Data Summary:
      ---
      ${dataSummary}
      ---

      Provide insights on potential reasons for churn and suggest specific strategies for customer retention, marketing, and service improvement.
    `;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt
    });

    return response.text;
  } catch (error) {
    console.error("Error generating insights with Gemini API:", error);
    if (error instanceof Error) {
        return `An error occurred while generating insights: ${error.message}`;
    }
    return "An unexpected error occurred while generating insights.";
  }
};
