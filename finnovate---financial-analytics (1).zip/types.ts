
export enum Page {
  Home = 'Home',
  Dashboard = 'Dashboard',
  Prediction = 'Prediction',
  Insights = 'Insights',
  SignIn = 'SignIn',
  SignUp = 'SignUp',
}

export type Theme = 'light' | 'dark';

export interface CustomerData {
  [key: string]: string | number;
  gender: string;
  SeniorCitizen: number;
  Partner: string;
  Dependents: string;
  tenure: number;
  PhoneService: string;
  MultipleLines: string;
  InternetService: string;
  OnlineSecurity: string;
  OnlineBackup: string;
  DeviceProtection: string;
  TechSupport: string;
  StreamingTV: string;
  StreamingMovies: string;
  Contract: string;
  PaperlessBilling: string;
  PaymentMethod: string;
  MonthlyCharges: number;
  TotalCharges: number;
  Churn?: 'Yes' | 'No';
}